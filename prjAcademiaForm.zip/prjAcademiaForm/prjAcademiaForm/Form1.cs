﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjAcademiaForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Academia boaforma;
        BindingSource bs;

        private void Form1_Load(object sender, EventArgs e)
        {
            BindingList<Aluno> lista = new BindingList<Aluno>();
            bs = new BindingSource();
            boaforma = new Academia(lista);
            PreencherLista();
            bs.DataSource = boaforma.Alunos;
            bn.BindingSource = bs;
            dgvLista.DataSource = bs;
            dgvLista.AutoResizeColumns();
            dgvLista.Columns["Classificacao"].DefaultCellStyle.ForeColor = Color.Red;
            dgvLista.Columns["Altura"].DefaultCellStyle.Format = "N2";
            dgvLista.Columns["IMC"].DefaultCellStyle.Format = "N2";
        }

        private void PreencherLista()
        {
            ServidorSQL banco = new ServidorSQL();
            if (banco.CriarBanco())
            {
                MessageBox.Show("Banco academia foi criado com sucesso!");
            }

            AlunoDB tabela = new AlunoDB();
            tabela.Consultar(boaforma.Alunos);
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            FormFichaMatricula ficha = new FormFichaMatricula();
            ficha.BoaForma = boaforma;
            ficha.Registro = null;
            ficha.ShowDialog();
            if (ficha.Registro != null)
            {
                bs.ResetBindings(false);
                dgvLista.AutoResizeColumns();
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            FormFichaMatricula ficha = new FormFichaMatricula();
            ficha.BoaForma = boaforma;
            ficha.Registro = (Aluno) bs.Current;
            ficha.ShowDialog();
            if (ficha.Registro != null)
            {
                bs.ResetBindings(false);
                dgvLista.AutoResizeColumns();
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            Aluno Registro = (Aluno)bs.Current;
            DialogResult op;
            op = MessageBox.Show("Apagar: " + Registro.Nome, "ALERTA", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (op == DialogResult.Yes)
            {
                boaforma.Excluir(Registro);
                bs.ResetBindings(false);
                bs.MoveLast();
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            //gravarArquivo();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            //gravarArquivo();

            Environment.Exit(0);
        }

        /*private void gravarArquivo()
        {
            string caminho = Environment.CurrentDirectory + "\\lista.txt";
            StreamWriter Arquivo = new StreamWriter(caminho);
            foreach (Aluno item in boaforma.Alunos)
            {
                string linha = String.Format("{0};{1};{2};{3};{4}", item.Id, item.Nome, item.Idade, item.Peso, item.Altura);
                Arquivo.WriteLine(linha);
            }

            Arquivo.Close();
        }*/

        private void txtNomePesq_TextChanged(object sender, EventArgs e)
        {
            AlunoDB tabela = new AlunoDB();
            tabela.pesquisar(boaforma.Alunos, txtNomePesq.Text);
        }
    }
}
