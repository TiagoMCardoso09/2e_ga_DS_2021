﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using System.IO;

namespace prjAcademiaForm
{
    class ServidorSQL
    {
        public SQLiteConnection Conexao { get; set; }
        public SQLiteConnection Open()
        {
            string caminho = Environment.CurrentDirectory + "\\academia.sqlite";
            string database = String.Format("Data Source = {0}; version = 3;", caminho);
            Conexao = new SQLiteConnection(database);
            Conexao.Open();
            return Conexao;
        }

        public bool CriarBanco()
        {
            string caminho = Environment.CurrentDirectory + "\\academia.sqlite";
            if (!File.Exists(caminho))
            {
                SQLiteConnection.CreateFile(caminho);
                CriarTabelas();
                return true;
            }
            return false;
        }

        private void CriarTabelas()
        {
            using (var banco = new SQLiteCommand(Open()))
            {
                try
                { 
                    banco.CommandText = "CREATE TABLE ALUNO (ID INT PRIMARY KEY, NOME VARCHAR(45), IDADE INT, PESO DOUBLE, ALTURA DOUBLE)";
                    banco.ExecuteNonQuery();

                }
                catch (Exception Erro)
                {
                    System.Windows.Forms.MessageBox.Show("Erro ao criar tabelas do banco" + Erro.Message);
                }
            }

        }
    }
}
