﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjAcademiaForm
{
    public partial class FormFichaMatricula : Form
    {
        internal Academia BoaForma { get; set; }
        internal Aluno Registro { get; set; }
        public FormFichaMatricula()
        {
            InitializeComponent();
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            if (Validacoes() == false) return;
            if (Registro == null) novo();
            else editar();

            this.Dispose();
        }

        private bool Validacoes()
        {
            if (txtNome.Text == string.Empty)
            {
                ep.SetError(txtNome, "Nome não pode ser gravado vazio!");
                ep.SetIconPadding(txtNome, -18);
                return false;
            }
            else ep.SetError(txtNome, "");

            if (txtIdade.Text == string.Empty)
            {
                ep.SetError(txtNome, "Idade não pode ser gravado vazio!");
                ep.SetIconPadding(txtNome, -18);
                return false;
            }
            else ep.SetError(txtNome, "");

            int idade = Convert.ToInt16(txtIdade.Text);

            if (idade < 12)
            {
                ep.SetError(txtIdade, "Idade deve ser maior que 15 anos!");
                ep.SetIconPadding(txtIdade, -18);
                return false;
            }
            else ep.SetError(txtIdade, "");

            int peso = Convert.ToInt16(txtPeso.Text);

            if (peso < 25 || peso > 250)
            {
                ep.SetError(txtPeso, "Peso do aluno deve ser entre 25 e 250 quilos!");
                ep.SetIconPadding(txtPeso, -18);
                return false;
            }
            else ep.SetError(txtPeso, "");

            double altura = Convert.ToDouble(txtAltura.Text);

            if (altura < 1.00 || altura > 2.50)
            {
                ep.SetError(txtAltura, "Peso do aluno deve ser entre 25 e 250 quilos!");
                ep.SetIconPadding(txtAltura, -18);
                return false;
            }
            else ep.SetError(txtAltura, "");

            return true;
        }

        private void novo()
        {
            AlunoDB tabela = new AlunoDB();
            Registro = new Aluno()
            {
                Id = tabela.ProximoCod(),
                Nome = txtNome.Text,
                Idade = Int16.Parse(txtIdade.Text),
                Peso = Double.Parse(txtPeso.Text),
                Altura = Double.Parse(txtAltura.Text)
            };

            BoaForma.matricular(Registro);
            MessageBox.Show("Matricula efetuada!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); ;
        }

        private void editar()
        {
            Registro.Nome = txtNome.Text;
            Registro.Idade = Int16.Parse(txtIdade.Text);
            Registro.Peso = Double.Parse(txtPeso.Text);
            Registro.Altura = Double.Parse(txtAltura.Text);

            BoaForma.editar(Registro);
            MessageBox.Show("Matricula editada!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); ;
        }

        private void FormFichaMatricula_Load(object sender, EventArgs e)
        {
            if (Registro != null)
            {
                txtNome.Text = Registro.Nome;
                txtIdade.Text = Registro.Idade.ToString();
                txtPeso.Text = Registro.Peso.ToString();
                txtAltura.Text = Registro.Altura.ToString();
            }

            txtNome.Focus();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Registro = null;
            this.Dispose();
        }
    }
}
