﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjAcademiaForm
{
    class Aluno
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public int Idade { get; set; }
        public double Peso { get; set; }
        public double Altura { get; set; }
        public Aluno(int Id, string Nome, int Idade, double Peso, double Altura)
        {
            this.Id = Id;
            this.Nome = Nome;
            this.Idade = Idade;
            this.Altura = Altura;
            this.Peso = Peso;
        }
        public Aluno()
            : this(0, "nome do aluno", 15, 60, 1.50)
        {
        }
        public double IMC
        {
            get
            {
                double calculo = this.Peso / Math.Pow(this.Altura, 2);
                return Math.Round(calculo);
            }
        }
        public string Classificacao
        {
            get
            {
                if (IMC < 18.5) return "BAIXO PESO";
                else if (IMC >= 18.5 && IMC <= 24.9) return "PESO NORMAL";
                else if (IMC >= 25 && IMC <= 29.9) return "SOBREPESO";
                else if (IMC >= 30 && IMC <= 34.9) return "OBESIDADE I";
                else if (IMC >= 35 && IMC <= 39.9) return "OBESIDADE II";
                else if (IMC >= 40 && IMC <= 49.9) return "OBESIDADE III";
                else return "OBESIDADE IV";
            }
        }
    }
}
