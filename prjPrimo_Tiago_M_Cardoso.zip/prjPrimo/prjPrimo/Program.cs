﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjPrimo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Clear();
            Console.WriteLine("Teste de Estresse de Processador com Números Primos");
            Console.WriteLine("Precione qualquer tecla para ecxecutar cálculo....");
            Console.ReadKey();
            Console.ForegroundColor = ConsoleColor.White;
            DateTime inicio = DateTime.Now;
            NumeroPrimo.Imprimir(1, 100000);
            DateTime fim = DateTime.Now;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Teste finalizado....");
            TimeSpan tempo = fim - inicio;
            Console.WriteLine("Tempo de Execução do processador i5-8265U: {0} segundos", tempo.TotalSeconds);
            Console.ReadKey();
        }
    }
}
