﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjPrimo
{
    class NumeroPrimo
    {
        public static void Imprimir(int vi, int vf)
        {
            for (int i = vi; i <= vf; i++)
            {
                if (TestarNumero(i))
                {
                    Console.WriteLine("{0} é número primo", i);
                }
            }
        }

        private static bool TestarNumero(int i)
        {
            int div = 0;
            for (int x = 1; x <= i; x++)
            {
                if (i % x == 0) div++;
            }
            if (div <= 2) return true;
            return false;
        }
    }
}
