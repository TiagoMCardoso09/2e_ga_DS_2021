﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace prjFolhaPagamento
{
    class CalcularSalarioEmpregado:ICalcularSalario
    {
        public int Cod { get; set; }
        public string Nome { get; set; }
        public double HorasTrabalhadas { get; set; }
        public CalcularSalarioEmpregado(int Cod, string Nome, double HorasTrabalhadas)
        {
            this.Cod = Cod;
            this.Nome = Nome;
            this.HorasTrabalhadas = HorasTrabalhadas;
        }
        public CalcularSalarioEmpregado()
            : this(0, "", 0f)
        {
        }
        public double CalcularSalarioBruto(double SalarioHora)
        {
            // calcula o salario bruto horas * valor do Salario Hora
            double sb = HorasTrabalhadas * SalarioHora;
            return sb;
        }
        public void Imprimir()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("----------------------------");
            Console.WriteLine("CALCULO SALARIO FUNCIONARIO");
            Console.WriteLine("----------------------------");
            Console.WriteLine("COD:{0}\tNOME:{1}", Cod, Nome.ToUpper());
            Console.WriteLine("HORAS TRABALHADAS: {0} HORAS MES", HorasTrabalhadas);
        }
    }
}