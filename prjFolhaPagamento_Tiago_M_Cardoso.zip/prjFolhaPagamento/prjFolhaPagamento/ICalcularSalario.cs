﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjFolhaPagamento
{
    interface ICalcularSalario
    {
        double CalcularSalarioBruto(double SalarioHora);
        void Imprimir();
    }
}
