﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace prjFolhaPagamento
{
    class MainClass
    {
        static List<ICalcularSalario> Funcionarios;
        public static void Main(string[] args)
        {
            Funcionarios = new List<ICalcularSalario>();
            Funcionarios.Add(new CalcularSalarioEmpregado()
            {
                Cod = 1,
                Nome = "JOAO CARLOS DA SILVA",
                HorasTrabalhadas = 160
            });
            Funcionarios.Add(new CalcularSalarioAposentado()
            {
                Cod = 2,
                Nome = "BONIFACIO DE OLIVEIRA FILHO"
            });
            Funcionarios.Add(new CalcularSalarioEstagiario()
            {
                Cod = 3,
                Nome = "ASPIRA DE MACEDO",
                HorasTrabalhadas = 53,
                Auxilio = 80
            });
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Clear();
            foreach (var func in Funcionarios)
            {
                if (func is CalcularSalarioEmpregado) ImprimirFolha(func, 15);
                if (func is CalcularSalarioAposentado) ImprimirFolha(func, 16);
                if (func is CalcularSalarioEstagiario) ImprimirFolha(func, 9);
            }
            Console.ReadKey();
        }
        public static void ImprimirFolha(ICalcularSalario func, double sh)
        {
            func.Imprimir();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Salario Bruto: {0:C2}",
            func.CalcularSalarioBruto(sh));
        }
    }
}