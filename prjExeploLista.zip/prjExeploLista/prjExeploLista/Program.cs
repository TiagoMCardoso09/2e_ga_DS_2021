﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjExeploLista
{
    class Program
    {
        static void Main(string[] args)
        {
            //Listas de objetos e valores
            List<Produto> Produtos;
            //tipo dinamico ArrayList<> em Java, C++, Lisp, Rustfly, Fluter, GO ETC...

            Produtos= new List<Produto>();
            Produtos.Add(new Produto("Produto 1",200));
            Produtos.Add(new Produto("Produto 2",180));
            Produtos.Add(new Produto("Produto 3", 78));
            Produtos.Add(new Produto("Produto 4", 90));

            foreach (Produto p in Produtos)
            {
                Console.Write("\t{0}", p.Nome);
            }

            Produtos.Reverse();
            Console.WriteLine();

            foreach (Produto p in Produtos)
            {
                Console.Write("\t{0}", p.Nome);
            }

            Produtos.OrderBy(i => i.Nome);
            Console.WriteLine();

            foreach (Produto p in Produtos)
            {
                Console.Write("\t{0}", p.Nome);
            }

            //Métodos agregador de uma lista
            Console.WriteLine("\nSoma:{0}", Produtos.Sum(i => i.Valor));
            Console.WriteLine("Média:{0}", Produtos.Average(i => i.Valor));
            Console.WriteLine("Maior:{0}", Produtos.Max(i => i.Valor));
            Console.WriteLine("Menor:{0}", Produtos.Min(i => i.Valor));

            Console.ReadKey();
        }
    }
}
