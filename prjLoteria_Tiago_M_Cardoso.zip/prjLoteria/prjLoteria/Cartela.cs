﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
--------------------------
-- Tiago Macedo Cardoso --
-- 2º ano E             --
--------------------------
*/

namespace prjLoteria
{
    class Cartela
    {
        public Label[] Numeros { get; set; }

        public Cartela(int qtd)
        {
            Numeros = new Label[qtd];
            for (int i = 0; i < qtd; i++)
            {
                Numeros[i] = new Label();
                Numeros[i].Text = (i + 1).ToString().PadLeft(2, '0');
                if (i == 99) Numeros[i].Text = "00";
                Numeros[i].ForeColor = Color.White;
                Numeros[i].AutoSize = false;
                Numeros[i].BorderStyle = BorderStyle.FixedSingle;
                Numeros[i].TextAlign = ContentAlignment.MiddleCenter;
                Numeros[i].Font = new Font("Arial", 14);
            }
        }

        public void Desenhar(Panel p, int linhas, int colunas)
        {
            int pv = 0;
            int ph = 0;

            int largura = p.Width / colunas;
            int altura = p.Height / linhas;

            for (int i = 0; i < Numeros.Count(); i++)
            {
                Numeros[i].Height = altura;
                Numeros[i].Width = largura;

                if (i % colunas == 0 && i != 0)
                {
                    pv += altura;
                    ph = 0;
                }

                Numeros[i].Top = pv;
                p.Controls.Add(Numeros[i]);
                Numeros[i].Left = ph;
                ph += largura;
                Numeros[i].Show();
            }
        }

        public void sortear(int faixa, int qtd)
        {
            List<int> Lista = new List<int>();
            Random sorteio = new Random();

            for (int i = 0; i < qtd; i++)
            {
                int num = sorteio.Next(0, faixa);
                if (Lista.Contains(num))
                {
                    i--;
                    continue;
                }
                Lista.Add(num);
                Thread.Sleep(1);
            }

            string caminho = Environment.CurrentDirectory + "\\select.png";

            foreach (int pos in Lista)
            {
                Numeros[pos].ForeColor = Color.Red;
                Numeros[pos].Image = Image.FromFile(caminho);
            }
        }
    }
}
