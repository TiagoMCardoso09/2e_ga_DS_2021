﻿namespace prjLoteria
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnSuperior = new System.Windows.Forms.Panel();
            this.lbTitulo = new System.Windows.Forms.Label();
            this.pnInferior = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.rbMegaSena = new System.Windows.Forms.RadioButton();
            this.rbLotomania = new System.Windows.Forms.RadioButton();
            this.rbLotoFacil = new System.Windows.Forms.RadioButton();
            this.rbQuina = new System.Windows.Forms.RadioButton();
            this.btnGerarCartela = new System.Windows.Forms.Button();
            this.pnCentro = new System.Windows.Forms.Panel();
            this.pnSuperior.SuspendLayout();
            this.pnInferior.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnSuperior
            // 
            this.pnSuperior.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(143)))), ((int)(((byte)(89)))));
            this.pnSuperior.Controls.Add(this.lbTitulo);
            this.pnSuperior.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnSuperior.Location = new System.Drawing.Point(0, 0);
            this.pnSuperior.Name = "pnSuperior";
            this.pnSuperior.Size = new System.Drawing.Size(702, 51);
            this.pnSuperior.TabIndex = 0;
            // 
            // lbTitulo
            // 
            this.lbTitulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(22)))), ((int)(((byte)(217)))));
            this.lbTitulo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbTitulo.Font = new System.Drawing.Font("Elephant", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitulo.ForeColor = System.Drawing.Color.Gainsboro;
            this.lbTitulo.Location = new System.Drawing.Point(0, 0);
            this.lbTitulo.Name = "lbTitulo";
            this.lbTitulo.Size = new System.Drawing.Size(702, 51);
            this.lbTitulo.TabIndex = 0;
            this.lbTitulo.Text = "GERADOR DE CARTELAS PARA LOTERIA";
            this.lbTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnInferior
            // 
            this.pnInferior.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(22)))), ((int)(((byte)(217)))));
            this.pnInferior.Controls.Add(this.btnGerarCartela);
            this.pnInferior.Controls.Add(this.rbQuina);
            this.pnInferior.Controls.Add(this.rbLotoFacil);
            this.pnInferior.Controls.Add(this.rbLotomania);
            this.pnInferior.Controls.Add(this.rbMegaSena);
            this.pnInferior.Controls.Add(this.label1);
            this.pnInferior.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnInferior.Location = new System.Drawing.Point(0, 394);
            this.pnInferior.Name = "pnInferior";
            this.pnInferior.Size = new System.Drawing.Size(702, 69);
            this.pnInferior.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 11F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.LightGray;
            this.label1.Location = new System.Drawing.Point(7, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(216, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "TIPOS DE CARTELAS:";
            // 
            // rbMegaSena
            // 
            this.rbMegaSena.AutoSize = true;
            this.rbMegaSena.Checked = true;
            this.rbMegaSena.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbMegaSena.ForeColor = System.Drawing.Color.LightGray;
            this.rbMegaSena.Location = new System.Drawing.Point(10, 38);
            this.rbMegaSena.Name = "rbMegaSena";
            this.rbMegaSena.Size = new System.Drawing.Size(110, 23);
            this.rbMegaSena.TabIndex = 1;
            this.rbMegaSena.TabStop = true;
            this.rbMegaSena.Text = "MegaSena";
            this.rbMegaSena.UseVisualStyleBackColor = true;
            // 
            // rbLotomania
            // 
            this.rbLotomania.AutoSize = true;
            this.rbLotomania.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbLotomania.ForeColor = System.Drawing.Color.LightGray;
            this.rbLotomania.Location = new System.Drawing.Point(123, 38);
            this.rbLotomania.Name = "rbLotomania";
            this.rbLotomania.Size = new System.Drawing.Size(112, 23);
            this.rbLotomania.TabIndex = 2;
            this.rbLotomania.Text = "Lotomania";
            this.rbLotomania.UseVisualStyleBackColor = true;
            // 
            // rbLotoFacil
            // 
            this.rbLotoFacil.AutoSize = true;
            this.rbLotoFacil.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbLotoFacil.ForeColor = System.Drawing.Color.LightGray;
            this.rbLotoFacil.Location = new System.Drawing.Point(235, 38);
            this.rbLotoFacil.Name = "rbLotoFacil";
            this.rbLotoFacil.Size = new System.Drawing.Size(102, 23);
            this.rbLotoFacil.TabIndex = 3;
            this.rbLotoFacil.Text = "LotoFacil";
            this.rbLotoFacil.UseVisualStyleBackColor = true;
            // 
            // rbQuina
            // 
            this.rbQuina.AutoSize = true;
            this.rbQuina.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbQuina.ForeColor = System.Drawing.Color.LightGray;
            this.rbQuina.Location = new System.Drawing.Point(337, 38);
            this.rbQuina.Name = "rbQuina";
            this.rbQuina.Size = new System.Drawing.Size(76, 23);
            this.rbQuina.TabIndex = 4;
            this.rbQuina.Text = "Quina";
            this.rbQuina.UseVisualStyleBackColor = true;
            // 
            // btnGerarCartela
            // 
            this.btnGerarCartela.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(159)))), ((int)(((byte)(242)))));
            this.btnGerarCartela.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGerarCartela.Font = new System.Drawing.Font("Elephant", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGerarCartela.ForeColor = System.Drawing.Color.White;
            this.btnGerarCartela.Location = new System.Drawing.Point(411, 6);
            this.btnGerarCartela.Name = "btnGerarCartela";
            this.btnGerarCartela.Size = new System.Drawing.Size(285, 57);
            this.btnGerarCartela.TabIndex = 5;
            this.btnGerarCartela.Text = "GERAR CARTELA";
            this.btnGerarCartela.UseVisualStyleBackColor = false;
            this.btnGerarCartela.Click += new System.EventHandler(this.btnGerarCartela_Click);
            // 
            // pnCentro
            // 
            this.pnCentro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(159)))), ((int)(((byte)(242)))));
            this.pnCentro.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnCentro.Location = new System.Drawing.Point(0, 51);
            this.pnCentro.Name = "pnCentro";
            this.pnCentro.Size = new System.Drawing.Size(702, 343);
            this.pnCentro.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(222)))), ((int)(((byte)(235)))));
            this.ClientSize = new System.Drawing.Size(702, 463);
            this.Controls.Add(this.pnCentro);
            this.Controls.Add(this.pnInferior);
            this.Controls.Add(this.pnSuperior);
            this.Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PROGRAMA LOTERIA";
            this.pnSuperior.ResumeLayout(false);
            this.pnInferior.ResumeLayout(false);
            this.pnInferior.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnSuperior;
        private System.Windows.Forms.Label lbTitulo;
        private System.Windows.Forms.Panel pnInferior;
        private System.Windows.Forms.Button btnGerarCartela;
        private System.Windows.Forms.RadioButton rbQuina;
        private System.Windows.Forms.RadioButton rbLotoFacil;
        private System.Windows.Forms.RadioButton rbLotomania;
        private System.Windows.Forms.RadioButton rbMegaSena;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnCentro;
    }
}

