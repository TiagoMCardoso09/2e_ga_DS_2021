﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
--------------------------
-- Tiago Macedo Cardoso --
-- 2º ano E             --
--------------------------
*/

namespace prjLoteria
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGerarCartela_Click(object sender, EventArgs e)
        {
            if (rbMegaSena.Checked==true)
            {
                pnCentro.Controls.Clear();
                Cartela c = new Cartela(60);
                c.Desenhar(pnCentro, 6, 10);
                c.sortear(60, 6);
            }

            if (rbLotomania.Checked == true)
            {
                pnCentro.Controls.Clear();
                Cartela c = new Cartela(100);
                c.Desenhar(pnCentro, 10, 10);
                c.sortear(100, 50);
            }

            if (rbLotoFacil.Checked == true)
            {
                pnCentro.Controls.Clear();
                Cartela c = new Cartela(25);
                c.Desenhar(pnCentro, 5, 5);
                c.sortear(25, 15);
            }

            if (rbQuina.Checked == true)
            {
                pnCentro.Controls.Clear();
                Cartela c = new Cartela(80);
                c.Desenhar(pnCentro, 8, 10);
                c.sortear(80, 5);
            }
        }
    }
}
