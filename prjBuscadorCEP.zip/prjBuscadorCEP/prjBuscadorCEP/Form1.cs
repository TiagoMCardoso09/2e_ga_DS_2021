﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjBuscadorCEP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private async void btnPesquisar_Click(object sender, EventArgs e)
        {
            CepWeb cep = new CepWeb();
            dynamic resultado = await cep.Consultar(txtCep.Text);
            if (resultado != null)
            {
                try
                {
                    lbEndereco.Text = resultado.logradouro;
                    lbBairro.Text = resultado.bairro;
                    lbCidade.Text = resultado.localidade + " DDD:" + resultado.ddd;
                    lbEstado.Text = resultado.uf;
                }
                catch (Exception)
                {
                    MessageBox.Show("CEP não encontrado!");
                }
            }
            else
            {
                MessageBox.Show("Erro ao acessar a Web!");
            }
        }
    }
}
