﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjBuscadorCEP
{
    class CepWeb
    {
        private async Task<string> ConectarWeb (string URL)
        {
            //Theread - Linha de execução
            using (var cliente = new System.Net.Http.HttpClient())
            {
                cliente.BaseAddress = new Uri(URL);
                cliente.DefaultRequestHeaders.Accept.Clear();
                var response = await cliente.GetAsync(URL);
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    return json.ToString();
                }
            }
            return "";
        }

        public async Task<dynamic> Consultar (string cep)
        {
            string jsonsite = await ConectarWeb(string.Format("https://viacep.com.br/ws/{0}/json", cep));
            if (jsonsite.Equals("")) return null;
            dynamic pesquisa = Newtonsoft.Json.JsonConvert.DeserializeObject(jsonsite);
            return pesquisa;
        }
    }
}
