﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjExtenso_Sala_de_Aula
{
    class Extenso
    {
        private static string ImprimirUnidades(int n)
        {
            string[] unidades = new string[]{
                "zero", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove"
            };
            return unidades[n];
        }
        
        private static string ImprimirDezenas(int n)
        {
            string valor = n.ToString();

            int d = Int16.Parse(valor.Substring(0, 1));
            int u = Int16.Parse(valor.Substring(1, 1));

            string[] dezenas = new string[]{
                "", "dez", "vinte", "trinta", "quarenta", "cinquenta", "sessenta", "setenta", "oitenta", "noventa"
            };

            string[] du = new string[]{
                "", "onze", "doze", "treze", "quatorze", "quinze", "dezesseis", "dezessete", "dezoito", "dezenove"
            };

            if (u == 0) return dezenas[d];
            if (d == 1) return du[u];

            return dezenas[d] + " e " + Imprimir(u);
        }

        private static string ImprimirCentenas(int n)
        {
            string valor = n.ToString();

            int c = Int16.Parse(valor.Substring(0, 1));
            int d = Int16.Parse(valor.Substring(1, 2));

            string[] centenas = new string[]{
                "", "cento", "duzentos", "trezentos", "quatrocentos", "quinhentos", "seiscentos", "setecentos", "oitocentos", "novecentos"
            };

            if (n == 10) return "cem";
            if (d == 0) return centenas[c];
            return centenas[c] + " e " + Imprimir(d);
        }

        private static string ImprimirMilhar(int n)
        {
            string valor = n.ToString();

            int m = Int16.Parse(valor.Substring(0, 1));
            int c = Int16.Parse(valor.Substring(1, 3));

            if (n == 1000) return "mil";
            if (c <= 100 || c%100 == 0) return Imprimir(m) + " mil e " + Imprimir(c);
            return Imprimir(m) + " mil, " + Imprimir(c);
        }

        public static string Imprimir(int n)
        {
            string valor = n.ToString();

            if (valor.Length == 1) return ImprimirUnidades(n);
            if (valor.Length == 2) return ImprimirDezenas(n);
            if (valor.Length == 3) return ImprimirCentenas(n);
            if (valor.Length == 4) return ImprimirMilhar(n);
            return "";
        }
    }
}
