﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace prjExtenso_Sala_de_Aula
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Clear();
            Console.WriteLine("TESTE DE NÚMERO EXTENSO");
            Console.ReadKey();
            Console.WriteLine();

            for (int i = 0; i < 31; i++)
            {
                Console.WriteLine("{0} = {1}", i, Extenso.Imprimir(i));
                Thread.Sleep(100);
            }

            for (int i = 100; i < 121; i++)
            {
                Console.WriteLine("{0} = {1}", i, Extenso.Imprimir(i));
                Thread.Sleep(100);
            }

            int numero;
            ConsoleKeyInfo tecla;

            do
            {
                Console.Write("Digite um número:");
                numero = Int16.Parse(Console.ReadLine());
                Console.WriteLine("{0} = {1}\n", numero, Extenso.Imprimir(numero));
                Console.Write("Digite ESC para sair:");
                tecla = Console.ReadKey();
            } while (tecla.Key != ConsoleKey.Escape);
        }
    }
}
