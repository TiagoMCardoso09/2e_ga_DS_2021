﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace prjExtenso
{
    class Program
    {
        static void Main(string[] args)
        {
            int escolha;
            int repetir;

            do
            {
                Console.BackgroundColor = ConsoleColor.Black;
                Console.ForegroundColor = ConsoleColor.Green;

                repetir = 0;

                do
                {
                    escolha = 0;

                    Console.Clear();
                    Console.WriteLine("TESTE DE NÚMEROS POR EXTENSO\n");
                    Console.WriteLine("Selecione uma opção:\n\t0-PARA SAIR DO PROGRAMA\n\t1-PARA O EXPRESSO\n\t2-PARA O TESTE COMPLETO\n\t3-PARA ESCOLHER UM VALOR");

                    escolha = Int16.Parse(Console.ReadLine());

                    if (escolha != 0 && escolha != 1 && escolha != 2 && escolha != 3)
                    {
                        Console.WriteLine("O valor digitado foi diferente das opções!\nPrecione qualquer tecla para escolher novamente.");
                        Console.ReadKey();
                    }
                } while (escolha != 0 && escolha != 1 && escolha != 2 && escolha != 3);

                Console.WriteLine("\n");

                //Rodando entre pulos

                if (escolha == 1)
                {
                    Console.ForegroundColor = ConsoleColor.Red;

                    for (int i = 1; i < 30; i++)
                    {
                        Console.WriteLine("{0} em extenso = {1}", i, Extenso.Imprimir(i));
                        Thread.Sleep(50);
                    }

                    Console.ForegroundColor = ConsoleColor.Yellow;

                    for (int i = 30; i < 100; i += 5)
                    {
                        Console.WriteLine("{0} em extenso = {1}", i, Extenso.Imprimir(i));
                        Thread.Sleep(50);
                    }

                    Console.ForegroundColor = ConsoleColor.Magenta;

                    for (int i = 100; i < 990; i += 110)
                    {
                        Console.WriteLine("{0} em extenso = {1}", i, Extenso.Imprimir(i));
                        Console.WriteLine("{0} em extenso = {1}", i + 3, Extenso.Imprimir(i + 3));
                        Console.WriteLine("{0} em extenso = {1}", i + 8, Extenso.Imprimir(i + 8));
                        Thread.Sleep(50);
                    }

                    Console.ForegroundColor = ConsoleColor.Cyan;

                    for (int i = 1000; i < 10000; i += 1010)
                    {
                        Console.WriteLine("{0} em extenso = {1}", i, Extenso.Imprimir(i));
                        Console.WriteLine("{0} em extenso = {1}", i + 3, Extenso.Imprimir(i + 3));
                        Console.WriteLine("{0} em extenso = {1}", i + 8, Extenso.Imprimir(i + 8));

                        Thread.Sleep(50);
                    }
                }

                //Rodando em 1 por 1

                else if (escolha == 2)
                {
                    Console.ForegroundColor = ConsoleColor.Red;

                    for (int i = 1; i < 30; i++)
                    {
                        Console.WriteLine("{0} em extenso = {1}", i, Extenso.Imprimir(i));
                        Thread.Sleep(1);
                    }

                    Console.ForegroundColor = ConsoleColor.Yellow;

                    for (int i = 30; i < 100; i++)
                    {
                        Console.WriteLine("{0} em extenso = {1}", i, Extenso.Imprimir(i));
                        Thread.Sleep(1);
                    }

                    Console.ForegroundColor = ConsoleColor.Magenta;

                    for (int i = 100; i < 990; i++)
                    {
                        Console.WriteLine("{0} em extenso = {1}", i, Extenso.Imprimir(i));
                        Thread.Sleep(1);
                    }

                    Console.ForegroundColor = ConsoleColor.Cyan;

                    for (int i = 1000; i < 10000; i++)
                    {
                        Console.WriteLine("{0} em extenso = {1}", i, Extenso.Imprimir(i));
                        Thread.Sleep(1);
                    }
                }

                if (escolha == 3)
                {
                    int NumEscolha;

                    Console.WriteLine("Digite o valor que deseja escrever:");
                    NumEscolha = Int16.Parse(Console.ReadLine());

                    Console.ForegroundColor = ConsoleColor.Red;

                    Console.WriteLine("\n{0} em extenso = {1}", NumEscolha, Extenso.Imprimir(NumEscolha));
                }
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                Console.WriteLine("\nTeste finalizado!\n\nDigite 1 para reinciar o programa ou 2 para sair.");
                repetir = Int16.Parse(Console.ReadLine());
            } while (repetir == 1);
        }
    }
}