﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjExtenso
{
    class Extenso
    {
        public static string Imprimir(int n)
        {
            string valor = n.ToString();
            if (valor.Length == 1) return ImprimirUnidades(n);
            else if (valor.Length == 2) return ImprimirDezena(n);
            else if (valor.Length == 3) return ImprimirCentena(n);
            else if (valor.Length == 4) return ImprimirMilhar(n);
            else return "";
        }

        private static string ImprimirUnidades(int n)
        {
            string[] unidades = new string[] { "zero", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove" };

            return unidades[n];
        }

        private static string ImprimirDezena(int n)
        {
            string[] dezena = new string[] { "", "dez", "vinte", "trinta", "quarenta", "cinquenta", "sessenta", "setenta", "oitenta", "noventa" };

            string[] dezenaUnidade = new string[]{
                "dez", "onze", "doze", "treze", "quatorze", "quinze", "dezesseis", "dezessete", "dezoito", "dezenove"
            };
            
            char[] valor = n.ToString().ToCharArray();

            if (valor[1] == '0')
        	{
                return dezena[Int16.Parse(valor[0].ToString())];
	        }
            else if (valor[0] == '1' && valor[1] != '0')
            {
                return dezenaUnidade[Int16.Parse(valor[1].ToString())];
            }
            else
            {
                return dezena[Int16.Parse(valor[0].ToString())] + " e " + ImprimirUnidades(Int16.Parse(valor[1].ToString()));
            }
        }

        private static string ImprimirCentena(int n)
        {
            string[] centena = new string[] { "", "cento", "duzentos", "trezentos", "quatrocentos", "quinhentis", "seiscentos", "selecentos", "oitocentos", "novecentos" };
            if (n == 100) return "cem";
            string valor = n.ToString();
            int c = Int16.Parse(valor.Substring(0, 1));
            return centena[c] + " e " + Imprimir(Int16.Parse(valor.Substring(1, valor.Length - 1)));
        }

        private static string ImprimirMilhar(int n)
        {
            string valor = n.ToString();
            if (n == 1000) return "mil";
            return ImprimirUnidades(Int16.Parse(valor.Substring(0, 1))) + " mil e " + Imprimir(Int16.Parse(valor.Substring(1, valor.Length - 1)));
        }
    }
}
