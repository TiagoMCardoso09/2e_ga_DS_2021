﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjCalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Calculadora calc = new Calculadora("0", "");

        bool EstadoIgual = false;

        private void btnCE_Click(object sender, EventArgs e)
        {
            calc = new Calculadora("0", "");
            lbVisor.Text = calc.Visor;
        }

        private void btnC_Click(object sender, EventArgs e)
        {
            calc.Visor = "0";
            lbVisor.Text = calc.Visor;
        }

        private void TestarIgual(object sender, EventArgs e)
        {
            if (EstadoIgual)
            {
                btnCE_Click(sender, e);
                EstadoIgual = false;
            }
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            TestarIgual(sender, e);
            calc.setDigito(btn0.Text);
            lbVisor.Text = calc.Visor;
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            TestarIgual(sender, e);
            calc.setDigito(btn1.Text);
            lbVisor.Text = calc.Visor;
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            TestarIgual(sender, e);
            calc.setDigito(btn2.Text);
            lbVisor.Text = calc.Visor;
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            TestarIgual(sender, e);
            calc.setDigito(btn3.Text);
            lbVisor.Text = calc.Visor;
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            TestarIgual(sender, e);
            calc.setDigito(btn4.Text);
            lbVisor.Text = calc.Visor;
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            TestarIgual(sender, e);
            calc.setDigito(btn5.Text);
            lbVisor.Text = calc.Visor;
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            TestarIgual(sender, e);
            calc.setDigito(btn6.Text);
            lbVisor.Text = calc.Visor;
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            TestarIgual(sender, e);
            calc.setDigito(btn7.Text);
            lbVisor.Text = calc.Visor;
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            TestarIgual(sender, e);
            calc.setDigito(btn8.Text);
            lbVisor.Text = calc.Visor;
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            TestarIgual(sender, e);
            calc.setDigito(btn9.Text);
            lbVisor.Text = calc.Visor;
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            EstadoIgual = true;
            calc.calcular();
            lbVisor.Text = calc.Visor;
        }

        private void btnSomar_Click(object sender, EventArgs e)
        {
            calc.Op = "+";
        }

        private void btnSubtrair_Click(object sender, EventArgs e)
        {
            calc.Op = "-";
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            calc.Op = "*";
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            calc.Op = "/";
        }

        private void btnIverterSinal_Click(object sender, EventArgs e)
        {
            calc.IverterSinal();
            lbVisor.Text = calc.Visor;
        }

        private void btnPontoDecimal_Click(object sender, EventArgs e)
        {
            calc.PontoDecimal();
            lbVisor.Text = calc.Visor;
        }

        private void btnFracao_Click(object sender, EventArgs e)
        {
            EstadoIgual = true;
            calc.Fracao();
            lbVisor.Text = calc.Visor;
        }

        private void btnQuadrado_Click(object sender, EventArgs e)
        {
            EstadoIgual = true;
            calc.NumQuadrado();
            lbVisor.Text = calc.Visor;
        }

        private void btnRaiz_Click(object sender, EventArgs e)
        {
            EstadoIgual = true;
            calc.RaizQuadrada();
            lbVisor.Text = calc.Visor;
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            calc.Porcentagem();
            lbVisor.Text = calc.Visor;
        }

        private void btnApagar_Click(object sender, EventArgs e)
        {
            calc.Backspace();
            lbVisor.Text = calc.Visor;
        }

        private void btnSeno_Click(object sender, EventArgs e)
        {
            EstadoIgual = true;
            calc.Seno();
            lbVisor.Text = calc.Visor;
        }

        private void btnCosseno_Click(object sender, EventArgs e)
        {
            EstadoIgual = true;
            calc.Cosseno();
            lbVisor.Text = calc.Visor;
        }

        private void btnTangente_Click(object sender, EventArgs e)
        {
            EstadoIgual = true;
            calc.Tangente();
            lbVisor.Text = calc.Visor;
        }

        private void btnMetade_Click(object sender, EventArgs e)
        {
            EstadoIgual = true;
            calc.Metade();
            lbVisor.Text = calc.Visor;
        }

        private void btnPi_Click(object sender, EventArgs e)
        {
            EstadoIgual = true;
            calc.Pi();
            lbVisor.Text = calc.Visor;
        }

        private void btnLogaritimo_Click(object sender, EventArgs e)
        {
            EstadoIgual = true;
            calc.Log();
            lbVisor.Text = calc.Visor;
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char tecla = e.KeyChar;
            if (Char.IsDigit(tecla))
            {
                TestarIgual(sender, e);
                calc.setDigito(tecla.ToString());
                lbVisor.Text = calc.Visor;
            }
            if (tecla == '+') btnSomar_Click(sender, e);
            if (tecla == '-') btnSubtrair_Click(sender, e);
            if (tecla == '*') btnMultiplicar_Click(sender, e);
            if (tecla == '/') btnDividir_Click(sender, e);
            if (tecla == '=') btnCalcular_Click(sender, e);
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back) btnApagar_Click(sender, e);
        }

        private void mnSair_Click(object sender, EventArgs e)
        {
            //Comando para fechar o programa
            Environment.Exit(0);
        }

        private void mnConversorTemperatura_Click(object sender, EventArgs e)
        {
            pjtTermometro.FormTermometro janela = new pjtTermometro.FormTermometro();
            janela.Show();
        }
    }
}
