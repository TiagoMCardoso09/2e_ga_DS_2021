﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjPessoa
{
    class Program
    {
        static List<IPessoa> Clientes;

        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Green;
            Clientes = new List<IPessoa>();
            Clientes.Add(new PessoaFisica("JOAO DA SILVA", "RUA CENTRAL, PARQUE INDUSTRIAL", "111.444.777-35"));
            Clientes.Add(new PessoaJuridica("BOA FORMA", "RUA CENTRAL, PARQUE INDUSTRIAL", "11.222.333/0001-81"));

            Console.Clear();

            Clientes.ForEach(c => imprimir(c));

            Console.ReadKey();
        }
        public static void imprimir(IPessoa p)
        {
            Console.WriteLine("{0}\tCNPJ: {1}", p.imprimir(), p.Validar() == true ? "Válido" : "Inválido");
        }
    }
}
