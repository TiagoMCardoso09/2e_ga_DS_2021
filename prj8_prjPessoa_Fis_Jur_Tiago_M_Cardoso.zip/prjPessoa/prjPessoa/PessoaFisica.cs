﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjPessoa
{
    class PessoaFisica : Pessoa, IPessoa
    {
        public string CPF { get; set; }
        public PessoaFisica(string Nome, string Endereco, string CPF)
            : base(Nome, Endereco)
        {
            this.CPF = CPF;
        }
        public bool Validar()
        {
            string documento = CPF.Remove(3,1);
            documento = documento.Remove(6,1);
            documento = documento.Remove(9, 1);

            string[] digitos = documento.ToCharArray().Select(i => i.ToString()).ToArray();

            int soma = 0;
            int peso = 10;

            for (int i = 0; i < 9; i++)
            {
                int n = Int16.Parse(digitos[i]);
                soma += n * peso;
                peso--;
            }
            int resto = soma % 11;
            int div1 = resto < 2 ? 0 : 11 - resto;
            if (!div1.ToString().Equals(digitos[9])) return false;

            soma = 0;
            peso = 11;

            for (int i = 0; i < 10; i++)
            {
                int n = Int16.Parse(digitos[i]);
                soma += n * peso;
                peso--;
            }
            resto = soma % 11;
            int div2 = resto < 2 ? 0 : 11 - resto;
            if (!div2.ToString().Equals(digitos[10])) return false;

            return true;
        }

        public new string imprimir()
        {
            return base.imprimir() + String.Format("CPF: {0}\t", CPF);
        }
    }
}
