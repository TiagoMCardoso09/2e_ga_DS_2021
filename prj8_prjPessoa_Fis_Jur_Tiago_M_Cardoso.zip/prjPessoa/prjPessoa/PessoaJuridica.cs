﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjPessoa
{
    class PessoaJuridica : Pessoa, IPessoa
    {
        public string CNPJ { get; set; }
        public PessoaJuridica(string Nome, string Endereco, string CNPJ)
            : base(Nome, Endereco)
        {
            this.CNPJ = CNPJ;
        }

        public bool Validar()
        {
            string documento = CNPJ.Remove(2, 1);
            documento = documento.Remove(5, 1);
            documento = documento.Remove(8, 1);
            documento = documento.Remove(12, 1);

            string[] digitos = documento.ToCharArray().Select(i => i.ToString()).ToArray();

            int soma = 0;
            int peso = 5;

            for (int i = 0; i < 12; i++)
            {
                int n = Int16.Parse(digitos[i]);
                if (peso < 2) peso = 9;
                soma += n * peso;
                peso--;
            }
            int resto = soma % 11;
            int div1 = resto < 2 ? 0 : 11 - resto;
            if (!div1.ToString().Equals(digitos[12])) return false;

            soma = 0;
            peso = 6;

            for (int i = 0; i < 13; i++)
            {
                int n = Int16.Parse(digitos[i]);
                if (peso < 2) peso = 9;
                soma += n * peso;
                peso--;
            }
            resto = soma % 11;
            int div2 = resto < 2 ? 0 : 11 - resto;
            if (!div2.ToString().Equals(digitos[13])) return false;

            return true;
        }

        public new string imprimir()
        {
            return base.imprimir() + String.Format("CNPJ: {0}", CNPJ);
        }
    }
}
