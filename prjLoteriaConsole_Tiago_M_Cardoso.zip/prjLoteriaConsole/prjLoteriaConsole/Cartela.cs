﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace prjLoteriaConsole
{
    class Cartela
    {
        public string[] Numeros { get; set; }
        private List<int> Lista = new List<int>();

        public Cartela(int qtd)
        {
            Numeros = new string[qtd];

            for (int i = 0; i < qtd; i++)
            {
                Numeros[i] = (i + 1).ToString().PadLeft(2, '0');
                if (i == 99) Numeros[i] = "00";
            }
        }

        public void Desenhar(int linhas, int colunas)
        {
            int pv = 1;
            int ph = 1;

            int largura = Console.WindowWidth / colunas;
            int altura = Console.WindowHeight / linhas;

            for (int i = 0; i < Numeros.Count(); i++)
            {
                if (i % colunas == 0 && i != 0)
                {
                    pv += altura;
                    ph = 1;
                }

                Console.CursorTop = pv;
                Console.CursorLeft = ph;

                if (Lista.Contains(Int16.Parse(Numeros[i])))
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                }

                Console.Write("{0}", Numeros[i]);

                ph += largura;
            }
        }

        public void sortear(int faixa, int qtd)
        {
            Random sorteio = new Random();

            for (int i = 0; i < qtd; i++)
            {
                int num = sorteio.Next(0, faixa);
                if (Lista.Contains(num))
                {
                    i--;
                    continue;
                }
                Lista.Add(num);
                Thread.Sleep(1);
            }
        }
    }
}
