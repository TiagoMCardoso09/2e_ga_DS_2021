﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjLoteriaConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Title = "Gerador de Cartelas";
            ConsoleKeyInfo tecla;

            do
            {
                Console.ForegroundColor = ConsoleColor.Green;

                Console.Clear();
                Console.WriteLine("---------------------------------------");
                Console.WriteLine("MENU GERADOR DE CARTELAS - MODO CONSOLE");
                Console.WriteLine("---------------------------------------");
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine("\t\t1-MegaSena");
                Console.WriteLine("\t\t2-Lotomania");
                Console.WriteLine("\t\t3-LotoFacil");
                Console.WriteLine("\t\t4-Quina");
                Console.WriteLine("\t\t5-SAIR DA APLICAÇÃO");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("---------------------------------------");
                Console.Write("Digite uma opção:");

                tecla = Console.ReadKey();
                if (tecla.Key == ConsoleKey.D1) megasena();
                if (tecla.Key == ConsoleKey.D2) lotomania();
                if (tecla.Key == ConsoleKey.D3) lotofacil();
                if (tecla.Key == ConsoleKey.D4) quina();
                if (tecla.Key == ConsoleKey.D5) sair();

            } while (tecla.Key != ConsoleKey.Escape);
        }

        private static void sair()
        {
            Environment.Exit(0);
        }

        private static void quina()
        {
            Console.Title = "Cartela para QUINA";
            Cartela jogo = new Cartela(80);
            Console.Clear();
            Console.CursorVisible = false;
            jogo.sortear(80, 5);
            jogo.Desenhar(8, 10);
            Console.ReadKey();
            Console.CursorVisible = true;
        }

        private static void lotofacil()
        {
            Console.Title = "Cartela para LOTOFACIL";
            Cartela jogo = new Cartela(25);
            Console.Clear();
            Console.CursorVisible = false;
            jogo.sortear(25, 15);
            jogo.Desenhar(5, 5);
            Console.ReadKey();
            Console.CursorVisible = true;
        }

        private static void lotomania()
        {
            Console.Title = "Cartela para LOTOMANIA";
            Cartela jogo = new Cartela(100);
            Console.Clear();
            Console.CursorVisible = false;
            jogo.sortear(100, 50);
            jogo.Desenhar(10, 10);
            Console.ReadKey();
            Console.CursorVisible = true;
        }
        private static void megasena()
        {
            Console.Title = "Cartela para MEGASENA";
            Cartela jogo = new Cartela(60);
            Console.Clear();
            Console.CursorVisible = false;
            jogo.sortear(60, 6);
            jogo.Desenhar(6, 10);
            Console.ReadKey();
            Console.CursorVisible = true;
        }
    }
}
