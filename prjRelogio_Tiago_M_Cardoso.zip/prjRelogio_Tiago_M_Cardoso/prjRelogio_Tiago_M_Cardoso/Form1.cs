﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjRelogio_Tiago_M_Cardoso
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string caminho = Environment.CurrentDirectory + "\\fundo.png";
        Graphics g;

        int hora;
        int min;
        int seg;

        int xseg, yseg;
        int xmin, ymin;
        int xhora, yhora;

        int audio = 1;

        Bitmap relogio;

        Color pixel;

        SoundPlayer tic;
        SoundPlayer tac;

        private void Form1_Load(object sender, EventArgs e)
        {
            if (!File.Exists(caminho))
            {
                openFileDialog1.Filter = "arquivo pgn | *.png";
                openFileDialog1.ShowDialog();
                File.Copy(openFileDialog1.FileName, caminho);
            }

            relogio = new Bitmap(pbRelogio.Width, pbRelogio.Height);
            g = Graphics.FromImage(relogio);
            pbRelogio.Paint += new PaintEventHandler(this.pbRelogio_Paint);
            pulso.Enabled = true;

        }

        void pbRelogio_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawImage(Image.FromFile(caminho), 0, 0, pbRelogio.Width, pbRelogio.Height);
        }

        private void pulso_Tick(object sender, EventArgs e)
        {
            hora = DateTime.Now.Hour;
            min = DateTime.Now.Minute;
            seg = DateTime.Now.Second;
                
            if (seg % 2 == 0 && audio == 1)
            {
                tic = new SoundPlayer();
                tic.SoundLocation = Environment.CurrentDirectory + "\\tic.wav";
                tic.Play();
            }
            else if (audio == 1)
            {
                tac = new SoundPlayer();
                tac.SoundLocation = Environment.CurrentDirectory + "\\tac.wav";
                tac.Play();
            }

            g.DrawImage(Image.FromFile(caminho), 0, 0, pbRelogio.Width, pbRelogio.Height);

            desenharSegundo();
            desenharMinuto();
            desenharHora();
            desenharCentro();
            pbRelogio.CreateGraphics().DrawImage(relogio, 0, 0, pbRelogio.Width, pbRelogio.Height);

            lblRelogioDigital.Text = DateTime.Now.ToLongTimeString();
        }

        private void desenharCentro()
        {
            int cx = pbRelogio.Width / 2;
            int cy = pbRelogio.Height / 2;

           
            SolidBrush balde = new SolidBrush(Color.FromArgb(pixel.ToArgb() ^ 0xffffff));
            g.FillEllipse(balde, cx - 10, cy - 10, 20, 20);
            
        }

        private void desenharMinuto()
        {
            int cx = pbRelogio.Width / 2;
            int cy = pbRelogio.Height / 2;
            double angulo = -90 + (min * (360 / 60));
            int raio = 110;

            Pen caneta = new Pen(Color.Transparent, 5);
            caneta.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
            
            g.DrawLine(caneta, cx, cy, cx + xmin, cy + ymin);

            double rad = Math.PI * angulo / 180;

            ymin = (int)(raio * Math.Sin(rad));
            xmin = (int)(raio * Math.Cos(rad));

            caneta.Color = Color.FromArgb(pixel.ToArgb() ^ 0xffffff);

            g.DrawLine(caneta, cx, cy, cx + xmin, cy + ymin);
        }

        private void desenharSegundo()
        {
            int cx = pbRelogio.Width / 2;
            int cy = pbRelogio.Height / 2;
            double angulo = -90 + (seg * (360 / 60));
            int raio = 110;

            Pen caneta = new Pen(Color.Transparent, 4);
            caneta.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
            g.DrawLine(caneta, cx, cy, cx + xseg, cy + yseg);

            double rad = Math.PI * angulo / 180;
            xseg = (int) (raio * Math.Cos(rad));
            yseg = (int)(raio * Math.Sin(rad));

            pixel = relogio.GetPixel(cx, cy);
            caneta.Color = Color.FromArgb(pixel.ToArgb()^0xffffff);
            lblRelogioDigital.BackColor = Color.FromArgb(pixel.ToArgb());
            lblRelogioDigital.ForeColor = Color.FromArgb(pixel.ToArgb() ^ 0xffffff);;

            g.DrawLine(caneta, cx, cy, cx + xseg, cy + yseg);
        }
        private void desenharHora()
        {
            int cx = pbRelogio.Width / 2;
            int cy = pbRelogio.Height / 2;

            if (hora > 12) hora = hora - 12;
            double angulo = -90 + (hora * (360 / 12));
            angulo += (min / 12) * 6;

            int raio = 110;

            Pen caneta = new Pen(Color.Transparent, 8);
            caneta.EndCap = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
            g.DrawLine(caneta, cx, cy, cx + xhora, cy + yhora);

            double rad = Math.PI * angulo / 180;

            yhora = (int)(raio * Math.Sin(rad));
            xhora = (int)(raio * Math.Cos(rad));

            caneta.Color = Color.FromArgb(pixel.ToArgb() ^ 0xffffff);

            g.DrawLine(caneta, cx, cy, cx + xhora, cy + yhora);
        }

        private void mnMostrador_Click(object sender, EventArgs e)
        {
            pulso.Enabled = false;
            openFileDialog1.ShowDialog();
            if (File.Exists(openFileDialog1.FileName))
            {
                GC.Collect();
                GC.WaitForPendingFinalizers();
                File.Delete(caminho);
                File.Copy(openFileDialog1.FileName, caminho);
            }
            pulso.Enabled = true;
        }

        private void audioLigado_Click(object sender, EventArgs e)
        {
            audio = 1;
        }

        private void audioDesligado_Click(object sender, EventArgs e)
        {
            audio = 0;
        }

        private void mnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
