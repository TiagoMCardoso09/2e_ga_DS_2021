﻿namespace prjRelogio_Tiago_M_Cardoso
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pbRelogio = new System.Windows.Forms.PictureBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.pulso = new System.Windows.Forms.Timer(this.components);
            this.lblRelogioDigital = new System.Windows.Forms.Label();
            this.menu = new System.Windows.Forms.MenuStrip();
            this.mnSair = new System.Windows.Forms.ToolStripMenuItem();
            this.mnArquivo = new System.Windows.Forms.ToolStripMenuItem();
            this.mnMostrador = new System.Windows.Forms.ToolStripMenuItem();
            this.áUDIOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.audioLigado = new System.Windows.Forms.ToolStripMenuItem();
            this.audioDesligado = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.pbRelogio)).BeginInit();
            this.menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // pbRelogio
            // 
            this.pbRelogio.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbRelogio.Location = new System.Drawing.Point(13, 38);
            this.pbRelogio.Name = "pbRelogio";
            this.pbRelogio.Size = new System.Drawing.Size(490, 450);
            this.pbRelogio.TabIndex = 0;
            this.pbRelogio.TabStop = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // pulso
            // 
            this.pulso.Interval = 1000;
            this.pulso.Tick += new System.EventHandler(this.pulso_Tick);
            // 
            // lblRelogioDigital
            // 
            this.lblRelogioDigital.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRelogioDigital.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRelogioDigital.Location = new System.Drawing.Point(13, 501);
            this.lblRelogioDigital.Name = "lblRelogioDigital";
            this.lblRelogioDigital.Size = new System.Drawing.Size(490, 46);
            this.lblRelogioDigital.TabIndex = 1;
            this.lblRelogioDigital.Text = "00:00:00";
            this.lblRelogioDigital.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // menu
            // 
            this.menu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnSair,
            this.mnArquivo,
            this.áUDIOToolStripMenuItem});
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(515, 28);
            this.menu.TabIndex = 2;
            this.menu.Text = "menuStrip1";
            // 
            // mnSair
            // 
            this.mnSair.BackColor = System.Drawing.Color.Red;
            this.mnSair.Name = "mnSair";
            this.mnSair.Size = new System.Drawing.Size(52, 24);
            this.mnSair.Text = "SAIR";
            this.mnSair.Click += new System.EventHandler(this.mnSair_Click);
            // 
            // mnArquivo
            // 
            this.mnArquivo.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnMostrador});
            this.mnArquivo.Name = "mnArquivo";
            this.mnArquivo.Size = new System.Drawing.Size(85, 24);
            this.mnArquivo.Text = "ARQUIVO";
            // 
            // mnMostrador
            // 
            this.mnMostrador.Name = "mnMostrador";
            this.mnMostrador.Size = new System.Drawing.Size(181, 26);
            this.mnMostrador.Text = "MOSTRADOR";
            this.mnMostrador.Click += new System.EventHandler(this.mnMostrador_Click);
            // 
            // áUDIOToolStripMenuItem
            // 
            this.áUDIOToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.audioLigado,
            this.audioDesligado});
            this.áUDIOToolStripMenuItem.Name = "áUDIOToolStripMenuItem";
            this.áUDIOToolStripMenuItem.Size = new System.Drawing.Size(67, 24);
            this.áUDIOToolStripMenuItem.Text = "ÁUDIO";
            // 
            // audioLigado
            // 
            this.audioLigado.BackColor = System.Drawing.Color.Lime;
            this.audioLigado.Name = "audioLigado";
            this.audioLigado.Size = new System.Drawing.Size(181, 26);
            this.audioLigado.Text = "LIGADO";
            this.audioLigado.Click += new System.EventHandler(this.audioLigado_Click);
            // 
            // audioDesligado
            // 
            this.audioDesligado.BackColor = System.Drawing.Color.Red;
            this.audioDesligado.Name = "audioDesligado";
            this.audioDesligado.Size = new System.Drawing.Size(181, 26);
            this.audioDesligado.Text = "DESLIGADO";
            this.audioDesligado.Click += new System.EventHandler(this.audioDesligado_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(515, 560);
            this.Controls.Add(this.lblRelogioDigital);
            this.Controls.Add(this.pbRelogio);
            this.Controls.Add(this.menu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menu;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RELÓGIO";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbRelogio)).EndInit();
            this.menu.ResumeLayout(false);
            this.menu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbRelogio;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Timer pulso;
        private System.Windows.Forms.Label lblRelogioDigital;
        private System.Windows.Forms.MenuStrip menu;
        private System.Windows.Forms.ToolStripMenuItem mnArquivo;
        private System.Windows.Forms.ToolStripMenuItem mnMostrador;
        private System.Windows.Forms.ToolStripMenuItem mnSair;
        private System.Windows.Forms.ToolStripMenuItem áUDIOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem audioLigado;
        private System.Windows.Forms.ToolStripMenuItem audioDesligado;
    }
}

