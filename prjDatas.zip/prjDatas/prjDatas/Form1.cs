﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjDatas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcularIdade_Click(object sender, EventArgs e)
        {
            DateTime hoje = DateTime.Now;
            TimeSpan calculo = new TimeSpan();

            calculo = hoje - dtNascimento.Value;
            int idade = (int)Math.Truncate(calculo.TotalDays/365);

            lbIdade.Text = string.Format("Sua idade é {0} anos!\n Você viveu {1} minutos!", idade, calculo.TotalMinutes.ToString("N2"));
            string diaNascimento = dtNascimento.Value.ToString("dddd");
            lbIdade.Text += string.Format("\nVocê nasceu em um(a) {0}", diaNascimento);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dtNascimento.Value = dtNascimento.Value.AddYears(-15);
        }
    }
}
