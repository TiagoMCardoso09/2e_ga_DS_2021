﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace prjArvoreFractal
{
    class Arvore
    {
        public Graphics Tela { get; set; }
        public Pen Caneta { get; set; }

        public int Width { get; set; }
        public int Height { get; set; }
        public int Angulo{ get; set; }

        public Arvore(Graphics Tela, int Width, int Height)
        {
            this.Tela = Tela;
            Caneta = new Pen(Color.Black, 4);
            Angulo = 30;
            this.Width = Width;
            this.Height = Height;
        }

        public void Desenhar()
        {
            Tela.ResetTransform(); //Comando para limpar o sistema de coordenadas
            Tela.Clear(Color.Black);
            Tela.TranslateTransform(Width / 2, Height);
            Random sorteio = new Random();
            int R = sorteio.Next(20, 255);
            Thread.Sleep(1);
            int G = sorteio.Next(20, 255);
            Thread.Sleep(1);
            int B = sorteio.Next(20, 255);
            Caneta.Color = Color.FromArgb(R, G, B);
            Tronco(sorteio.Next(5, Height / 2));
        }

        private void Tronco(double len)
        {
            Tela.DrawLine(Caneta, 0, 0, 0, (int) -len);
            Tela.TranslateTransform(0,(float) -len, System.Drawing.Drawing2D.MatrixOrder.Prepend);
            if (len > 5)
            {
                GraphicsState Estado = Tela.Save();
                Tela.RotateTransform(Angulo, System.Drawing.Drawing2D.MatrixOrder.Prepend);
                Random sorteio = new Random();
                double crescimento = (double)sorteio.Next(40, 65);
                Tronco(len * crescimento/100);
                Tela.Restore(Estado);
                Estado = Tela.Save();
                Tela.RotateTransform(-Angulo, System.Drawing.Drawing2D.MatrixOrder.Prepend);
                Tronco(len * 0.65);
                Tela.Restore(Estado);
            }
        }
    }
}
