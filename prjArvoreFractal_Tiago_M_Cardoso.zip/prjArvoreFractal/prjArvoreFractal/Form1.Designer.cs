﻿namespace prjArvoreFractal
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbArvore = new System.Windows.Forms.PictureBox();
            this.btnDesenhar = new System.Windows.Forms.Button();
            this.lbAngulo = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.hsbAngulo = new System.Windows.Forms.HScrollBar();
            this.btnExit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbArvore)).BeginInit();
            this.SuspendLayout();
            // 
            // pbArvore
            // 
            this.pbArvore.Location = new System.Drawing.Point(12, 12);
            this.pbArvore.Name = "pbArvore";
            this.pbArvore.Size = new System.Drawing.Size(1041, 476);
            this.pbArvore.TabIndex = 0;
            this.pbArvore.TabStop = false;
            // 
            // btnDesenhar
            // 
            this.btnDesenhar.AutoSize = true;
            this.btnDesenhar.BackColor = System.Drawing.Color.DimGray;
            this.btnDesenhar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDesenhar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDesenhar.ForeColor = System.Drawing.Color.White;
            this.btnDesenhar.Location = new System.Drawing.Point(12, 503);
            this.btnDesenhar.Name = "btnDesenhar";
            this.btnDesenhar.Size = new System.Drawing.Size(649, 68);
            this.btnDesenhar.TabIndex = 1;
            this.btnDesenhar.Text = "Desenhar Árvore";
            this.btnDesenhar.UseVisualStyleBackColor = false;
            this.btnDesenhar.Click += new System.EventHandler(this.btnDesenhar_Click);
            // 
            // lbAngulo
            // 
            this.lbAngulo.BackColor = System.Drawing.Color.DimGray;
            this.lbAngulo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbAngulo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbAngulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAngulo.ForeColor = System.Drawing.Color.White;
            this.lbAngulo.Location = new System.Drawing.Point(802, 503);
            this.lbAngulo.Name = "lbAngulo";
            this.lbAngulo.Size = new System.Drawing.Size(248, 68);
            this.lbAngulo.TabIndex = 2;
            this.lbAngulo.Text = "0";
            this.lbAngulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(678, 527);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "ANGULO:";
            // 
            // hsbAngulo
            // 
            this.hsbAngulo.Location = new System.Drawing.Point(12, 586);
            this.hsbAngulo.Maximum = 189;
            this.hsbAngulo.Minimum = 1;
            this.hsbAngulo.Name = "hsbAngulo";
            this.hsbAngulo.Size = new System.Drawing.Size(1041, 21);
            this.hsbAngulo.TabIndex = 4;
            this.hsbAngulo.Value = 1;
            this.hsbAngulo.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hsbAngulo_Scroll);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.DarkRed;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(12, 624);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(1038, 34);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "CLIQUE AQUI PARA FECHAR A APLICAÇÃO";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1062, 673);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.hsbAngulo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbAngulo);
            this.Controls.Add(this.btnDesenhar);
            this.Controls.Add(this.pbArvore);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Arvore Fractal";
            ((System.ComponentModel.ISupportInitialize)(this.pbArvore)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbArvore;
        private System.Windows.Forms.Button btnDesenhar;
        private System.Windows.Forms.Label lbAngulo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.HScrollBar hsbAngulo;
        private System.Windows.Forms.Button btnExit;
    }
}

