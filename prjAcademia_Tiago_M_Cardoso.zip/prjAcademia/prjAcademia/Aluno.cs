﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjAcademia
{
    class Aluno
    {
        //Tiago Macedo Cardoso
        //2º ano E

        public int Id { get; set; }
        public string Nome { get; set; }
        public int Idade { get; set; }
        public double Peso { get; set; }
        public double Altura { get; set; }

        public Aluno(int Id, string Nome, int Idade, double Peso, double Altura)
        {
            this.Id = Id;
            this.Nome = Nome;
            this.Idade = Idade;
            this.Altura = Altura;
            this.Peso = Peso;
        }

        public Aluno():this(0, "Nome do Aluno", 15, 60, 1.50)
        {
            
        }

        public double IMC()
        {
            return this.Peso / Math.Pow(this.Altura, 2);
        }

        public string Classificacao()
        {
            double indice = IMC();
            if (indice < 18.5) return "BAIXO PESO";
            else if (indice >= 18.5 && indice <= 24.9) return "PESO NORMAL";
            else if (indice >= 25 && indice <= 29.9) return "SOBREPESO";
            else if (indice >= 30 && indice <= 34.9) return "OBESIDADE I";
            else if (indice >= 35 && indice <= 39.9) return "OBESIDADE II";
            else if (indice >= 40 && indice <= 49.9) return "OBESIDADE III";
            else return "OBESIDADE IV";
        }
        public string imprimir()
        {
            return String.Format("\nID:{0}\tNOME:{1}\tIDADE:{2}\nPESO:{3}\tALTURA:{4}", Id, Nome, Idade, Peso, Idade);
        }
    }
}
