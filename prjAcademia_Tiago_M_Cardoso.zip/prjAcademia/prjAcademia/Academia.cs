﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjAcademia
{
    class Academia
    {
        //Tiago Macedo Cardoso
        //2º ano E

        public List<Aluno> Alunos { get; set; }

        public Academia(List<Aluno> Alunos)
        {
            this.Alunos = Alunos;
        }

        public string ImprimirClassificacao()
        {
            string texto = "";

            foreach (Aluno reg in Alunos)
            {
                texto += reg.imprimir();
                texto += String.Format("\nIMC:{0}\tCLASSIFICAÇÂO:{1}\n",
                    reg.IMC().ToString("N2"),reg.Classificacao());
            }

            return texto;
        }
        public void matricular(Aluno novo)
        {
            Alunos.Add(novo);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(novo.imprimir());
        }

        internal Aluno Pesquisar(int Cod)
        {
            return Alunos.FirstOrDefault(reg => reg.Id == Cod);
        }

        public void Excluir(Aluno reg)
        {
            Alunos.Remove(reg);
        }
    }
}