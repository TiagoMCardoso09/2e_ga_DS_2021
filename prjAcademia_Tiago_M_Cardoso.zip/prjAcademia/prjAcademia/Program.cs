﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjAcademia
{
    class MainClass
    {
        //Tiago Macedo Cardoso
        //2º ano E

        static Academia boaforma;

        public static void Main(string[] args)
        {
            List<Aluno> lista = new List<Aluno>();

            PreencherLista(lista);
            boaforma = new Academia(lista);

            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;

            ConsoleKeyInfo tecla;

            do
            {
                Menu();
                tecla = Console.ReadKey(true);
                if (tecla.Key == ConsoleKey.D1) classificacao();
                if (tecla.Key == ConsoleKey.D2) matricular();
                if (tecla.Key == ConsoleKey.D3) excluir();
                if (tecla.Key == ConsoleKey.D4) editar();
            } while (tecla.Key != ConsoleKey.D5);

            GravarArquivo();

        }

        private static void GravarArquivo()
        {
            string caminho = Environment.CurrentDirectory + "\\lista.txt";
            StreamWriter Arquivo = new StreamWriter(caminho);
            foreach (Aluno item in boaforma.Alunos)
            {
                string linha = String.Format("{0};{1};{2};{3};{4}", item.Id, item.Nome, item.Idade, item.Peso, item.Altura);
                Arquivo.WriteLine(linha);
            }

            Arquivo.Close();

        }

        private static void PreencherLista(List<Aluno> lista)
        {
            string caminho = Environment.CurrentDirectory + "\\lista.txt";
            StreamReader Arquivo = new StreamReader(caminho);
            int qtd = File.ReadAllLines(caminho).Count();

            for (int i = 0; i < qtd; i++)
            {
                string linha = Arquivo.ReadLine();
                string[] campos = linha.Split(';');
                Aluno novo = new Aluno();

                novo.Id = Convert.ToInt16(campos[0]);
                novo.Nome = campos[1];
                novo.Idade = Convert.ToInt16(campos[2]);
                novo.Peso = Convert.ToDouble(campos[3]);
                novo.Altura = Convert.ToDouble(campos[4]);

                lista.Add(novo);

            }
            Arquivo.Close();
        }

        private static void excluir()
        {
            Console.ForegroundColor = ConsoleColor.Red;

            Console.Clear();

            Console.Write("Digite o código do aluno: ");
            int Cod = Int16.Parse(Console.ReadLine());
            Aluno reg = boaforma.Pesquisar(Cod);
            if (reg != null)
            {
                boaforma.Excluir(reg);
                Console.WriteLine("Matricula EXCLUIDA!");
            }
            else
            {
                Console.WriteLine("Matrícula não encontrada!");
            }

            Console.Write("Pressione qualquer tecla:");
            Console.ReadKey();
        }

        private static void editar()
        {

            Console.ForegroundColor = ConsoleColor.DarkYellow;

            Console.Clear();

            Console.Write("Digite o código do aluno: ");
            int Cod = Int16.Parse(Console.ReadLine());
            Aluno reg = boaforma.Pesquisar(Cod);

            if (reg != null)
            {
                Console.Write("Insira o novo NOME do aluno: ");
                reg.Nome = Console.ReadLine();

                Console.Write("Insira o novo PESO do aluno:");
                reg.Peso = Convert.ToDouble(Console.ReadLine());

                Console.Write("Insira a nome do ALTURA aluno");
                reg.Altura = Convert.ToDouble(Console.ReadLine());

                Console.Write("Insira a IDADE do novo aluno");
                reg.Idade = Convert.ToInt16(Console.ReadLine());

                Console.WriteLine("Registro editado com sucesso!");
            }
            else
            {
                Console.WriteLine("Matricula não encontrada!");
            }

            Console.Write("Pressione qualquer tecla:");
            Console.ReadKey();
        }

        private static void classificacao()
        {
            Console.ForegroundColor = ConsoleColor.Blue;

            Console.Clear();
            Console.WriteLine("---------------------------------------------");
            Console.WriteLine("   CLASSIFICACAO ALUNOS ACADEMIA BOA FORMA   ");
            Console.WriteLine("---------------------------------------------");
            Console.WriteLine(boaforma.ImprimirClassificacao());
            Console.Write("Pressione qualquer tecla:");
            Console.ReadKey();
        }

        private static void matricular()
        {

            Console.ForegroundColor = ConsoleColor.Green;

            Console.Clear();

            Aluno novo = new Aluno();

            Console.Write("Insira a MATRÍCULA do novo aluno: ");
            novo.Id = Convert.ToInt16(Console.ReadLine());

            Console.Write("Insira o NOME do novo aluno: ");
            novo.Nome = Console.ReadLine();

            Console.Write("Insira o PESO do novo aluno: ");
            novo.Peso = Convert.ToDouble(Console.ReadLine());

            Console.Write("Insira a nome do ALTURA aluno: ");
            novo.Altura = Convert.ToDouble(Console.ReadLine());

            Console.Write("Insira a IDADE do novo aluno: ");
            novo.Idade = Convert.ToInt16(Console.ReadLine());

            boaforma.matricular(novo);

            Console.Write("Pressione qualquer tecla:");
            Console.ReadKey();
        }

        private static void Menu()
        {

            Console.ForegroundColor = ConsoleColor.White;

            Console.Clear();

            Console.WriteLine("SISTEMA DE CONTROLE DE ALUNOS");
            Console.WriteLine("-----------------------------");
            Console.WriteLine("       MENU DO SISTEMA       ");
            Console.WriteLine("-----------------------------");
            Console.WriteLine("1 - IMPRIMIR CLASSIFICAÇÃO");
            Console.WriteLine("2 - MATRICULAR ALUNO");
            Console.WriteLine("3 - EXCLUIR MATRÍCULA");
            Console.WriteLine("4 - EDITAR MATRÍCULA");
            Console.WriteLine("5 - SAIR DO SISTEMA");
            Console.WriteLine("-----------------------------");
            Console.Write(" DIGITE A OPÇÃO: ");
        }
    }
}
