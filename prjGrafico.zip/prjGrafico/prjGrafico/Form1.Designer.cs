﻿namespace prjGrafico
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.pnSuperior = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pnEsquerda = new System.Windows.Forms.Panel();
            this.kbDelta = new System.Windows.Forms.Panel();
            this.lbX2 = new System.Windows.Forms.Label();
            this.lbX1 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbDelta = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pnEsquerdaTopo = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.txtXF = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtB = new System.Windows.Forms.TextBox();
            this.txtXI = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtC = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtA = new System.Windows.Forms.TextBox();
            this.Grafico = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button1 = new System.Windows.Forms.Button();
            this.pnSuperior.SuspendLayout();
            this.pnEsquerda.SuspendLayout();
            this.kbDelta.SuspendLayout();
            this.pnEsquerdaTopo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Grafico)).BeginInit();
            this.SuspendLayout();
            // 
            // pnSuperior
            // 
            this.pnSuperior.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(85)))), ((int)(((byte)(53)))));
            this.pnSuperior.Controls.Add(this.label1);
            this.pnSuperior.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnSuperior.Location = new System.Drawing.Point(0, 0);
            this.pnSuperior.Name = "pnSuperior";
            this.pnSuperior.Size = new System.Drawing.Size(803, 39);
            this.pnSuperior.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(628, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "PLOTADOR DE EQUAÇÕES DO 2º GRAU";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnEsquerda
            // 
            this.pnEsquerda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(85)))), ((int)(((byte)(53)))));
            this.pnEsquerda.Controls.Add(this.button1);
            this.pnEsquerda.Controls.Add(this.kbDelta);
            this.pnEsquerda.Controls.Add(this.pnEsquerdaTopo);
            this.pnEsquerda.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnEsquerda.ForeColor = System.Drawing.Color.White;
            this.pnEsquerda.Location = new System.Drawing.Point(0, 39);
            this.pnEsquerda.Name = "pnEsquerda";
            this.pnEsquerda.Size = new System.Drawing.Size(200, 618);
            this.pnEsquerda.TabIndex = 1;
            // 
            // kbDelta
            // 
            this.kbDelta.Controls.Add(this.lbX2);
            this.kbDelta.Controls.Add(this.lbX1);
            this.kbDelta.Controls.Add(this.label10);
            this.kbDelta.Controls.Add(this.lbDelta);
            this.kbDelta.Controls.Add(this.label7);
            this.kbDelta.Controls.Add(this.label8);
            this.kbDelta.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.kbDelta.Location = new System.Drawing.Point(0, 401);
            this.kbDelta.Name = "kbDelta";
            this.kbDelta.Size = new System.Drawing.Size(200, 217);
            this.kbDelta.TabIndex = 7;
            // 
            // lbX2
            // 
            this.lbX2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbX2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbX2.ForeColor = System.Drawing.Color.White;
            this.lbX2.Location = new System.Drawing.Point(38, 168);
            this.lbX2.Name = "lbX2";
            this.lbX2.Size = new System.Drawing.Size(103, 27);
            this.lbX2.TabIndex = 5;
            this.lbX2.Text = "0";
            // 
            // lbX1
            // 
            this.lbX1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbX1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbX1.ForeColor = System.Drawing.Color.White;
            this.lbX1.Location = new System.Drawing.Point(38, 107);
            this.lbX1.Name = "lbX1";
            this.lbX1.Size = new System.Drawing.Size(103, 27);
            this.lbX1.TabIndex = 5;
            this.lbX1.Text = "0";
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(38, 147);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 18);
            this.label10.TabIndex = 4;
            this.label10.Text = "Valor X\'\':";
            // 
            // lbDelta
            // 
            this.lbDelta.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lbDelta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDelta.ForeColor = System.Drawing.Color.White;
            this.lbDelta.Location = new System.Drawing.Point(38, 48);
            this.lbDelta.Name = "lbDelta";
            this.lbDelta.Size = new System.Drawing.Size(103, 27);
            this.lbDelta.TabIndex = 5;
            this.lbDelta.Text = "0";
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(38, 86);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 18);
            this.label7.TabIndex = 4;
            this.label7.Text = "Valor X\':";
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(38, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 18);
            this.label8.TabIndex = 4;
            this.label8.Text = "DELTA:";
            // 
            // pnEsquerdaTopo
            // 
            this.pnEsquerdaTopo.Controls.Add(this.label2);
            this.pnEsquerdaTopo.Controls.Add(this.txtXF);
            this.pnEsquerdaTopo.Controls.Add(this.label4);
            this.pnEsquerdaTopo.Controls.Add(this.txtB);
            this.pnEsquerdaTopo.Controls.Add(this.txtXI);
            this.pnEsquerdaTopo.Controls.Add(this.label5);
            this.pnEsquerdaTopo.Controls.Add(this.label3);
            this.pnEsquerdaTopo.Controls.Add(this.txtC);
            this.pnEsquerdaTopo.Controls.Add(this.label6);
            this.pnEsquerdaTopo.Controls.Add(this.txtA);
            this.pnEsquerdaTopo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnEsquerdaTopo.Location = new System.Drawing.Point(0, 0);
            this.pnEsquerdaTopo.Name = "pnEsquerdaTopo";
            this.pnEsquerdaTopo.Size = new System.Drawing.Size(200, 327);
            this.pnEsquerdaTopo.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(38, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 18);
            this.label2.TabIndex = 0;
            this.label2.Text = "Valor A:";
            // 
            // txtXF
            // 
            this.txtXF.Location = new System.Drawing.Point(41, 271);
            this.txtXF.Name = "txtXF";
            this.txtXF.Size = new System.Drawing.Size(100, 22);
            this.txtXF.TabIndex = 5;
            this.txtXF.Text = "0";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(38, 139);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 18);
            this.label4.TabIndex = 4;
            this.label4.Text = "Valor C:";
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(41, 104);
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(100, 22);
            this.txtB.TabIndex = 3;
            this.txtB.Text = "0";
            // 
            // txtXI
            // 
            this.txtXI.Location = new System.Drawing.Point(41, 215);
            this.txtXI.Name = "txtXI";
            this.txtXI.Size = new System.Drawing.Size(100, 22);
            this.txtXI.TabIndex = 5;
            this.txtXI.Text = "0";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(38, 194);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 18);
            this.label5.TabIndex = 4;
            this.label5.Text = "Valor XI:";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(38, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 18);
            this.label3.TabIndex = 2;
            this.label3.Text = "Valor B:";
            // 
            // txtC
            // 
            this.txtC.Location = new System.Drawing.Point(41, 160);
            this.txtC.Name = "txtC";
            this.txtC.Size = new System.Drawing.Size(100, 22);
            this.txtC.TabIndex = 5;
            this.txtC.Text = "0";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(38, 250);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 18);
            this.label6.TabIndex = 4;
            this.label6.Text = "Valor XF:";
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(41, 49);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(100, 22);
            this.txtA.TabIndex = 1;
            this.txtA.Text = "0";
            // 
            // Grafico
            // 
            this.Grafico.BackColor = System.Drawing.Color.Green;
            this.Grafico.BorderlineColor = System.Drawing.SystemColors.Window;
            this.Grafico.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Grafico.Location = new System.Drawing.Point(200, 39);
            this.Grafico.Name = "Grafico";
            series2.Name = "Series1";
            this.Grafico.Series.Add(series2);
            this.Grafico.Size = new System.Drawing.Size(603, 618);
            this.Grafico.TabIndex = 2;
            this.Grafico.Text = "chart1";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(41, 333);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 62);
            this.button1.TabIndex = 8;
            this.button1.Text = "PLOTAR";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(803, 657);
            this.Controls.Add(this.Grafico);
            this.Controls.Add(this.pnEsquerda);
            this.Controls.Add(this.pnSuperior);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GERADOR GRÁFICO";
            this.pnSuperior.ResumeLayout(false);
            this.pnEsquerda.ResumeLayout(false);
            this.kbDelta.ResumeLayout(false);
            this.pnEsquerdaTopo.ResumeLayout(false);
            this.pnEsquerdaTopo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Grafico)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnSuperior;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnEsquerda;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtXF;
        private System.Windows.Forms.TextBox txtXI;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel kbDelta;
        private System.Windows.Forms.Label lbX1;
        private System.Windows.Forms.Label lbDelta;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel pnEsquerdaTopo;
        private System.Windows.Forms.Label lbX2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataVisualization.Charting.Chart Grafico;
        private System.Windows.Forms.Button button1;
    }
}

