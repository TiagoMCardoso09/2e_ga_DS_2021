﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjGrafico
{
    class Equacao2g
    {
        public double A { get; set; }
        public double B { get; set; }
        public double C { get; set; }

        public Equacao2g(double A, double B, double C)
        {
            this.A = A;
            this.B = B;
            this.C = C;
        }

        public double Delta
        {
            get
            {
                return B * B - 4 * A * C;
            }
        }

        public double X1
        {
            get
            {
                return (-B + Math.Sqrt(Delta)) / (2 * A);
            }
        }
        public double X1
        {
            get
            {
                return (-B - Math.Sqrt(Delta)) / (2 * A);
            }
        }
    }
}
