﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ExtensoDLL;

namespace prjCheque
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnEmitir_Click(object sender, EventArgs e)
        {
            string[] partes = txtValor.Text.Split(',');
            string real = Extenso.Imprimir(Int16.Parse(partes[0]));
            string centavo = Extenso.Imprimir(Int16.Parse(partes[1]));
            Graphics tela = pbCheque.CreateGraphics();
            SolidBrush cor = new SolidBrush(Color.Blue);
            tela.DrawString(real + " reais e " + centavo + " centavos", new Font("Arial", 12), cor, 200, 71);
            tela.DrawString(txtNome.Text, new Font("Arial", 12), cor, 35, 135);
            string mes = dtEmissao.Value.ToString("MMMM");
            tela.DrawString(mes, new Font("Arial", 12), cor, 465, 174);
            string ano = dtEmissao.Value.ToString("yyyy");
            tela.DrawString(ano, new Font("Arial", 12), cor, 595, 173);
            string diaNum = dtEmissao.Value.ToString("dd");
            string numDia = Extenso.Imprimir(Int16.Parse(diaNum));
            string dia = dtEmissao.Value.ToString("dddd, ");
            tela.DrawString(dia + numDia, new Font("Arial", 12), cor, 250, 173);
        }

        private void txtValor_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtNome.Focus();
            }
        }

        private void txtNome_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnEmitir_Click(sender, e);
            }
        }
    }
}