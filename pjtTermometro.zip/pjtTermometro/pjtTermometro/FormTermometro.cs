﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pjtTermometro
{
    public partial class FormTermometro : Form
    {
        public FormTermometro()
        {
            InitializeComponent();
        }

        private void btnConverter_Click(object sender, EventArgs e)
        {
            if (rbFromC.Checked == true && rbToK.Checked == true)
            {
                double c = Convert.ToDouble(txtTemperatura.Text);
                double k = c + 273.16;
                lbTemperatura.Text = "Kelvin\n" + k.ToString("N2");
            }
            if (rbFromK.Checked == true && rbToC.Checked == true)
            {
                double k = Convert.ToDouble(txtTemperatura.Text);
                double c = k - 273.16;
                lbTemperatura.Text = "Celsius\n" + c.ToString("N2");
            }
            if (rbFromF.Checked == true && rbToK.Checked == true)
            {
                double f = Convert.ToDouble(txtTemperatura.Text);
                double k = (f + 459.67) / 1.8;
                lbTemperatura.Text = "Kelvin\n" + k.ToString("N2");
            }
            if (rbFromK.Checked == true && rbToF.Checked == true)
            {
                double k = Convert.ToDouble(txtTemperatura.Text);
                double f = (k * 1.8) - 459.67;
                lbTemperatura.Text = "Fahrenheit\n" + f.ToString("N2");
            }
            if (rbFromC.Checked == true && rbToF.Checked == true)
            {
                double c = Convert.ToDouble(txtTemperatura.Text);
                double f = c * 1.8 + 32;
                lbTemperatura.Text = "Fahrenheit\n" + f.ToString("N2");
            }
            if (rbFromF.Checked == true && rbToC.Checked == true)
            {
                double f = Convert.ToDouble(txtTemperatura.Text);
                double c = (f - 32) / 1.8;
                lbTemperatura.Text = "Celsius\n" + c.ToString("N2");
            }
            if (rbFromC.Checked == true && rbToC.Checked == true || rbFromF.Checked == true && rbToF.Checked == true || rbFromK.Checked == true && rbToK.Checked == true)
            {
                double t = Convert.ToDouble(txtTemperatura.Text);
                lbTemperatura.Text = "NÃO CONVERTIDO!\n" + t.ToString("N2");
            }
        }
    }
}
